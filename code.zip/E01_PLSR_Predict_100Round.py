import scipy.stats as stats
import scipy.io as scio
import numpy as np
from sklearn.cross_decomposition import PLSRegression

from f_NFold import NFold


FOLD_NUM = 10
DIM = 5  # the number of latent variables
ROUND_NUM = 100
# partial least squares regression
data=scio.loadmat('./result/BetaMat.mat') #4 * 138 * 264
# Load information for each individual
SubjInfo=scio.loadmat("./data/SubjInfo178_222Label_200507.mat")['SubjInfo']
MIA_index=np.squeeze(data["MIA_index"])
SubjInfo=SubjInfo[MIA_index,:]
# Gender 2
# Age 220
# IQ 38 /39
# Crystal IQ 40/ 41
# Reading 13/14
# PictVoc 15/16
# Strength 174/175

# Gender 1  ;  IQ 37
LabelTmp = SubjInfo[:, 1]
# Find the number of valid sample
SubjNoUse = np.where(LabelTmp != -9999)[0]
Label = LabelTmp[SubjNoUse]
Label = Label[:,np.newaxis]
SampleSize = len(Label)


BetaMat=data['BetaMat']
CorrMat = BetaMat[:, SubjNoUse,:]
R=np.zeros((ROUND_NUM,4, 4))
RMSE=np.zeros((ROUND_NUM, 4, 4))
Predicted = np.zeros((ROUND_NUM, 4, 4, SampleSize))
for RoundNo in range(ROUND_NUM):

    [TrainNo, TestNo, Permed] = NFold(SampleSize, FOLD_NUM);

    for MovNo in range(4):
        for FoldNo in range(FOLD_NUM):
            LabelTrain = Label[TrainNo[FoldNo],:]
            CorrTrain =CorrMat[MovNo, TrainNo[FoldNo],:]

            LabelMean = np.mean(LabelTrain, 0)
            CorrMean = np.mean(CorrTrain, 0)
            pls = PLSRegression(n_components=5)
            pls.fit(CorrTrain,LabelTrain)
            Beta=pls.coef_
            for MovTargNo in range(4):
                CorrTest = CorrMat[MovTargNo, TestNo[FoldNo],:]
                CorrTest_Norm = CorrTest - CorrMean
                TestLabel_Pred = CorrTest_Norm.dot(Beta)
                Predicted[RoundNo, MovNo, MovTargNo, TestNo[FoldNo]] =np.squeeze(TestLabel_Pred + LabelMean)
        for MovTargNo in range(4):
            if (len(np.unique(np.squeeze(Label).astype(int))) == 2):
                # sex classification
                R[RoundNo, MovNo, MovTargNo] = sum(abs((Predicted[RoundNo, MovNo, MovTargNo, :] > 0.5) - np.squeeze(Label)) < 0.000001) / SampleSize
            else:
                # IQ prediction
                a=Predicted[RoundNo, MovNo, MovTargNo,:].tolist()
                b=np.squeeze(Label).tolist()
                r = stats.pearsonr(a, b)
                R[RoundNo, MovNo, MovTargNo] = r[0]
                RMSE[RoundNo, MovNo, MovTargNo] = np.sqrt(sum(np.square(Predicted[RoundNo, MovNo, MovTargNo, :] - np.squeeze(Label))) / (SampleSize - 1))

    MeanR = np.mean(R, 0)
    StdR = np.std(R, 0,ddof=1)

if (len(np.unique(np.squeeze(Label).astype(int))) == 2):
    scio.savemat("./result/Pred_PLSR264ROI_Gender_DIM5.mat",
    {"R":R,
    "Predicted":Predicted,
    "SubjInfo":SubjInfo,
    "SubjNoUse":SubjNoUse,
    "MeanR":MeanR,
    "StdR":StdR})
else:
    MeanRMSE = np.mean(RMSE, 0)
    StdRMSE = np.std(RMSE, 0)
    scio.savemat("./result/Pred_PLSR264ROI_ZIQ_DIM5.mat",
                 {"R": R,
                  "RMSE":RMSE,
                  "Predicted": Predicted,
                  "SubjInfo": SubjInfo,
                  "SubjNoUse": SubjNoUse,
                  "MeanR": MeanR,
                  "StdR": StdR,
                  "MeanRMSE":MeanRMSE,
                  "StdRMSE":StdRMSE})

