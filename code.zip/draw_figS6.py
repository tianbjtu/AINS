# FigS6
import numpy as np
import scipy.io as scio
import seaborn as sns
import pandas as pd
from matplotlib import pyplot as plt

plt.rcParams['axes.unicode_minus']=False
sns.set_theme(style="whitegrid",font='Times New Roman')
sns.set_context("notebook", font_scale=1.3, rc={"lines.linewidth": 2})
fig,sub_ax=plt.subplots(nrows=1,ncols=2,figsize = (12,6))
fig.subplots_adjust(hspace=0.3,wspace=0.3)


data=scio.loadmat("./result/Pred_PLSR264_360ROI_Gender_DIM5.mat")
MeanR=data['MeanR']
StdR=data['StdR']
XVarNames = ['Mov1','Mov2','Mov3','Mov4']
data=[ MeanR[i][i] for i in range(MeanR.shape[0])]
std_data=[StdR[i][i] for i in range(StdR.shape[0])]

df = pd.DataFrame({
                "movie_type":XVarNames,
                "Classification Rate":data,
})

ax3 = sns.barplot(x="movie_type", y="Classification Rate", data=df,palette="Purples",ci=None,ax=sub_ax[0])
ax3.errorbar(x=[0,1,2,3],y=df["Classification Rate"],yerr=(np.array(std_data)),fmt='none',c='b',elinewidth=2,capsize=4,capthick=2)

ax3.set_ylim(0, 0.9)
ax3.tick_params(labelsize=15)
ax3.set_xticklabels(XVarNames,size=15)
vals = ax3.get_yticks()
ax3.set_yticklabels(['{:.1%}'.format(x) for x in vals],size=12)
widthbars = [0.4,0.4,0.4,0.4]
for bar,newwidth in zip(ax3.patches,widthbars):
    x = bar.get_x()
    width = bar.get_width()
    centre = x+width/2.
    bar.set_x(centre-newwidth/2.)
    bar.set_width(newwidth)
ax3.set_ylabel("Classification Rate",fontsize=15)
ax3.set_xlabel("",fontsize=15)
ax3.set_title("(a)",loc='left',fontsize=20,y=1.05,x=-0.1,weight='bold')


data=scio.loadmat("./result/Pred_PLSR264_360ROI_ZIQ_DIM5.mat")
MeanR=data['MeanR']
StdR=data['StdR']
XVarNames = ['Mov1','Mov2','Mov3','Mov4']
data=[ MeanR[i][i] for i in range(MeanR.shape[0])]
std_data=[StdR[i][i] for i in range(StdR.shape[0])]

df = pd.DataFrame({
                "movie_type":XVarNames,
                "Correlation Coffficient":data,
})

ax4 = sns.barplot(x="movie_type", y="Correlation Coffficient", data=df,palette="Purples",ci=None,ax=sub_ax[1])
ax4.errorbar(x=[0,1,2,3],y=df["Correlation Coffficient"],yerr=(np.array(std_data)),fmt='none',c='b',elinewidth=2,capsize=4,capthick=2)

ax4.set_ylim(0, 0.45)
ax4.tick_params(labelsize=15)
ax4.set_xticklabels(XVarNames,size=15)

widthbars = [0.4,0.4,0.4,0.4]
for bar,newwidth in zip(ax4.patches,widthbars):
    x = bar.get_x()
    width = bar.get_width()
    centre = x+width/2.
    bar.set_x(centre-newwidth/2.)
    bar.set_width(newwidth)
ax4.set_ylabel("Correlation Coffficient",fontsize=15)
ax4.set_xlabel("",fontsize=15)
ax4.set_title("(b)",loc='left',fontsize=20,y=1.05,x=-0.1,weight='bold')
fig.savefig("./figure/figS6",dpi=300)
plt.show()