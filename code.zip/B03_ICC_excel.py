import numpy as np
import scipy.io as scio
import csv
import pandas as pd

data=scio.loadmat('./result/ICC_RA_AllSubj.mat')
corrdinate_data = pd.read_csv('./data/Power264coordinate.csv')
rows=[]
ICC_RA=data['ICC_RA'][0]
SortedICC =np.sort(ICC_RA)[::-1]
pos=np.argsort(ICC_RA)[::-1]


network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}

roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)
ROI_264=np.squeeze(ROI_264[:,np.newaxis])

roi_class=ROI_264[pos]

order_corrd=[]
X=corrdinate_data['MNI_X'].to_numpy()
Y=corrdinate_data['MNI_Y'].to_numpy()
Z=corrdinate_data['MNI_Z'].to_numpy()
for i in range(264):
    str_corrd="( "+str(+X[i])+", "+str(Y[i])+", "+str(Z[i])+" )"
    order_corrd.append(str_corrd)

for i in range(264):
    one_row={
             'MNI Coordinate':order_corrd[pos[i]],
             'Network Affiliation':network_name[roi_class[i]],
             'ICC':str(np.round(SortedICC[i],3))}
    rows.append(one_row)

with open('./result/RoiICC.csv', 'w', newline='')as csv_file:
    fieldnames=['MNI Coordinate','Network Affiliation','ICC']
    writer = csv.DictWriter(csv_file,fieldnames=fieldnames)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
