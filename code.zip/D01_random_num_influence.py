# Response model is built based on how many samples
import random
import numpy as np
from scipy.optimize import curve_fit
import scipy.io as scio
from f_ICC import icc

def func(x, a, b):
    return a + b*x

data_filepath=["./data/Movie1_TS264.mat","./data/Movie2_TS264.mat","./data/Movie3_TS264.mat","./data/Movie4_TS264.mat"]
random_num_list=[10, 20, 30, 40, 50,60,70,80,90,100,110,120,130]
Global_wise_ICC=np.zeros((4,13))

for movNo in range(4):
    for random_No in range(13):
        random_num=random_num_list[random_No]
        MIA_num=178-random_num
        BetaMat=np.zeros((2,MIA_num,264))
        temp= np.array([subjNO for subjNO in range(178)])
        random.shuffle(temp)
        model_index=temp[0:random_num]
        MIA_index=temp[random_num:]
        model_index_list=[model_index[0:random_num//2],model_index[random_num//2:]]

        for run_No in range(2):
            data=scio.loadmat(data_filepath[movNo])['TS'] # 脑区*时间点*样本数 264*696*178
            num_roi,num_time,num_sample=data.shape
            Movie_Matrix = np.zeros((MIA_num, num_roi))
            # 求random_num个样本的均值
            temp = data[:,:,model_index_list[run_No]]
            Movie_Mean = np.mean(temp, axis=2)
            for i in range(MIA_num):
                for j in range(num_roi):
                    popt, pcov = curve_fit(func, Movie_Mean[j,:], data[j,:, MIA_index[i]])
                    Movie_Matrix[i, j] = popt[1]
            BetaMat[run_No,:,:] = Movie_Matrix

        ICC_RA = np.zeros(num_roi)
        for Tmp in range(num_roi):
            ICC_RA[Tmp],_,_, _, _,_,_ = icc(BetaMat[:, :, Tmp].T, 0.05, 0)
        ICC_Glob = np.mean(ICC_RA)
        Global_wise_ICC[movNo][random_No]=ICC_Glob
scio.savemat("result/random_subj_Global_ICC.mat", {'Global_ICC':Global_wise_ICC})


