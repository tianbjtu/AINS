
import numpy as np
import scipy.io as scio
import seaborn as sns
import pandas as pd
from matplotlib import pyplot as plt

data=scio.loadmat("./result/Pred_PLSR264ROI_ZIQ_DIM5.mat")
MeanR=data['MeanR']
StdR=data['StdR']
XVarNames = ['Mov1','Mov2','Mov3','Mov4']
data=[ MeanR[i][i] for i in range(MeanR.shape[0])]
std_data=[StdR[i][i] for i in range(StdR.shape[0])]

df = pd.DataFrame({
                "movie_type":XVarNames,
                "Correlation Coffficient":data,
})
plt.rcParams['axes.unicode_minus']=False
sns.set(rc={'figure.figsize':(15,15)})
sns.set_theme(style="whitegrid",font='Times New Roman')
ax = sns.barplot(x="movie_type", y="Correlation Coffficient", data=df,color="#9999CC",ci=None)
plt.errorbar(x=[0,1,2,3],y=df["Correlation Coffficient"],yerr=(np.array(std_data)),fmt='none',c='b',elinewidth=5,capsize=10,capthick=8)

plt.ylim(0, 0.4)
plt.tick_params(labelsize=35)
ax.set_xticklabels(XVarNames,size=35)
widthbars = [0.5,0.5,0.5,0.5]
for bar,newwidth in zip(ax.patches,widthbars):
    x = bar.get_x()
    width = bar.get_width()
    centre = x+width/2.
    bar.set_x(centre-newwidth/2.)
    bar.set_width(newwidth)
plt.ylabel("Correlation Coffficient",fontsize=40)
plt.xlabel("")
ax.set_title("(f)", loc='left', fontsize=45, y=1.05, x=-0.15, weight='bold')
scatter_fig = ax.get_figure()
scatter_fig.savefig("./figure/fig5f",dpi=300)
plt.show()
