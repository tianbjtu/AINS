import numpy as np
import scipy.io as scio
import pandas as pd

network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}
network_color={1:0, 3:0, 4:4, 5:0, 7:1, 8:0, 9:0,
10:0, 11:2, 12:3, -1:0}
roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)

NodeColor=np.zeros(264)
for i in range(264):
    NodeColor[i]=network_color[ROI_264[i]]


NodeLabel=[]
for i in range(264):
    NodeLabel.append(ROI_264[i])
NodeLabel=np.array(NodeLabel)

BetaMat=scio.loadmat('./result/BetaMat.mat')['BetaMat']
tmp =np.mean(BetaMat,0)
RA = np.mean(tmp,0)
NodeSize_Num = RA

corrdinate_data = pd.read_csv('./data/Power264coordinate.csv')
X=corrdinate_data['MNI_X'].to_numpy()
X=X[:,np.newaxis]
Y=corrdinate_data['MNI_Y'].to_numpy()
Y=Y[:,np.newaxis]
Z=corrdinate_data['MNI_Z'].to_numpy()
Z=Z[:,np.newaxis]


NodeInfo=np.concatenate((X,Y,Z),1)

SortedNodeSize_Num  =np.sort(NodeSize_Num )[::-1]
pos=np.argsort(NodeSize_Num )[::-1]
SortedNodeInfo=NodeInfo[pos]
SortedNodeColor=NodeColor[pos]
SortedNodeLabel=NodeLabel[pos]


with open('./result/NodeSize_Num.node','w') as fp:
    for Tmp1 in range(50):
            fp.write("{:f}\t{:f}\t{:f}\t{:f}\t{:f}\t{:.0f}\n"
                     .format(SortedNodeInfo[Tmp1,0],SortedNodeInfo[Tmp1,1],SortedNodeInfo[Tmp1,2],SortedNodeColor[Tmp1],
                             SortedNodeSize_Num[Tmp1],SortedNodeLabel[Tmp1]))
