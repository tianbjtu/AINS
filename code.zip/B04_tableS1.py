import numpy as np
import scipy.io as scio
import csv
import pandas as pd

data=scio.loadmat('./result/SortMIA.mat')
corrdinate_data = pd.read_csv('./data/Power264coordinate.csv')
rows=[]
sorted_Mean_IRNS=data['SortedSIA'][0]
sorted_Std_IRNS=data['SortedStd'][0]
sorted_pos=data['pos'][0]
re_pos=np.argsort(sorted_pos)

ori_Mean_AINS=sorted_Mean_IRNS[re_pos]
ori_std_AINS=sorted_Std_IRNS[re_pos]

data=scio.loadmat('./result/ICC_RA_AllSubj.mat')
ICC_RA=data['ICC_RA'][0]

network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}

roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)
ROI_264=np.squeeze(ROI_264[:,np.newaxis])

order_corrd=[]

X=corrdinate_data['MNI_X'].to_numpy()
Y=corrdinate_data['MNI_Y'].to_numpy()
Z=corrdinate_data['MNI_Z'].to_numpy()
for i in range(264):
    str_corrd=str(+X[i])+", "+str(Y[i])+", "+str(Z[i])
    order_corrd.append(str_corrd)

for i in range(264):
    one_row={
             'MNI Coordinate':order_corrd[i],
             'Network Affiliation':network_name[ROI_264[i]],
             'AINS*':"{:.3f}".format(ori_Mean_AINS[i])+'±'+"{:.3f}".format(ori_std_AINS[i]),
             'ICC':"{:.3f}".format(ICC_RA[i])}
    rows.append(one_row)

with open('./result/TableS1.csv', 'w', newline='')as csv_file:
    fieldnames=['MNI Coordinate','Network Affiliation','AINS*','ICC']
    writer = csv.DictWriter(csv_file,fieldnames=fieldnames)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
