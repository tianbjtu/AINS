# FigS1
import scipy.io as scio
import seaborn as sns
import pandas as pd
from matplotlib import pyplot as plt

data=scio.loadmat("result/random_subj_Global_ICC.mat")['Global_ICC']
data=data.reshape(-1)
movie_type=[]
labels=[]
temp=[5,10,15,20,25,30,35,40,45,50,55,60,65]
for i in range (4):
    labels+=temp
    for j in range(13):
        movie_type.append("Mov"+str(i+1))

df = pd.DataFrame({
                "Number Of Subjects":labels,
                "Global-Wise ICC":data,
                "hue":movie_type,
})
plt.rcParams['axes.unicode_minus']=False
sns.set_theme(style="whitegrid",font='Times New Roman')
sns.set_context("notebook", font_scale=1.2, rc={"lines.linewidth": 2})
fig=plt.figure(figsize=(12, 12))
ax1=sns.lineplot(x="Number Of Subjects", y="Global-Wise ICC", hue="hue", data=df, ci=None)
handles, labels = ax1.get_legend_handles_labels()
ax1.legend(bbox_to_anchor = (1, 1),fontsize = 13)
plt.setp(ax1.get_legend().get_texts(), fontsize=13) # for legend text
ax1.tick_params(labelsize=25)
ax1.set_ylabel("Global-Wise ICC",fontsize=25)
ax1.set_xlabel("Number of Subjects Used for Response Model Establishment",fontsize=25)
fig.savefig("./figure/figS1",dpi=300)
plt.show()
