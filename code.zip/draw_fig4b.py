# draw fig4b
import numpy as np
import scipy.io as scio
import seaborn as sns
import pandas as pd
from matplotlib.ticker import FuncFormatter
from matplotlib import pyplot as plt
data=scio.loadmat('./result/BetaMat.mat')
BetaMat=data["BetaMat"]
MIA_index=np.squeeze(data["MIA_index"])


temp=np.mean(BetaMat,0)
temp=np.mean(temp,1)

mean_IRNS_pos=np.argsort(temp)[::-1]

sub1_index=mean_IRNS_pos[0]
sub2_index=mean_IRNS_pos[4]

Sub_all_data=scio.loadmat("./data/SubjInfo178_222Label_200507.mat")["SubjInfo"]
sub1_No="Subj"+"%d"%int(Sub_all_data[MIA_index[sub1_index]][0])
sub2_No="Subj"+"%d"%(int(Sub_all_data[MIA_index[sub2_index]][0]))
Sub1_BetaMat=BetaMat[:,sub1_index,:]
Sub2_BetaMat=BetaMat[:,sub2_index,:]

num_roi=264
roi=np.zeros(8*num_roi)
temp1=["Mov1","Mov2","Mov3","Mov4"]
temp2=[sub1_No,sub2_No]
movie_type=[]
event=[]
for i in range(2):
    for j in range(4):
        for k in range(num_roi):
            roi[i*4*num_roi+j * num_roi + k] = int(k)
            movie_type.append(temp1[j])
            event.append(temp2[i])

data=np.concatenate((Sub1_BetaMat.reshape(-1),Sub2_BetaMat.reshape(-1)),0)
data=data.tolist()
roi.astype(int)
roi=roi.tolist()

df = pd.DataFrame({
                "AINS": data,
                "ROI": roi,
                "movie_type":movie_type,
                "subject":event
})
plt.rcParams['axes.unicode_minus']=False
sns.set_theme(style="whitegrid",font='Times New Roman')
sns.set_context("notebook", font_scale=1.3, rc={"lines.linewidth": 2})
fig,sub_ax=plt.subplots(nrows=2,ncols=1,figsize = (16,12))
fig.subplots_adjust(hspace=0.2,wspace=0.2)

ax1=sns.lineplot(x="ROI", y="AINS",style="movie_type", hue="subject", data=df,ax=sub_ax[1])
ax1.legend().remove()
ax1.tick_params(labelsize=25)
def to_percent(temp, position):
    return '%d'%(temp)
ax1.xaxis.set_major_formatter(FuncFormatter(to_percent))
ax1.set_ylabel("AINS",fontsize=30)
ax1.set_xlabel("ROI No.",fontsize=30)

Sub1_BetaMat_visual=Sub1_BetaMat[:,156:166]
Sub2_BetaMat_visual=Sub2_BetaMat[:,156:166]

num_roi=10
Sub1_BetaMat_visual=Sub1_BetaMat_visual.reshape(-1)
Sub2_BetaMat_visual=Sub2_BetaMat_visual.reshape(-1)
roi=np.zeros(8*num_roi)

temp1=["Mov1","Mov2","Mov3","Mov4"]
temp2=[sub1_No,sub2_No]
movie_type=[]
event=[]
for i in range(2):
    for j in range(4):
        for k in range(num_roi):
            roi[i*4*num_roi+j * num_roi + k] = int(k)
            movie_type.append(temp1[j])
            event.append(temp2[i])

data=np.concatenate((Sub1_BetaMat_visual,Sub2_BetaMat_visual),0)
data=data.tolist()
roi.astype(int)
roi=roi.tolist()

df = pd.DataFrame({
                "AINS": data,
                "ROI": roi,
                " ":movie_type,
                "subject":event
})

ax2=sns.lineplot(x="ROI", y="AINS",style=" ", hue="subject", data=df,ax=sub_ax[0])
handles, labels = ax2.get_legend_handles_labels()
ax2.legend(handles=handles[1:], labels=labels[1:],bbox_to_anchor = (1, 1),fontsize = 13)
plt.setp(ax2.get_legend().get_texts(), fontsize=13) # for legend text
ax2.tick_params(labelsize=25)
def to_percent(temp, position):
    return '%d'%(temp+156)
ax2.xaxis.set_major_formatter(FuncFormatter(to_percent))
ax2.set_ylabel("AINS",fontsize=30)
ax2.set_xlabel("",fontsize=30)
ax2.set_title("(b)",loc='left',fontsize=45,y=1.05,x=-0.1,weight='bold')
fig.savefig("./figure/fig4b",dpi=300)
plt.show()


