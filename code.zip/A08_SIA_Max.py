# Calculate the activation standard deviation
# Sort according to the activation mean of each brain region
import numpy as np
import scipy.io as scio

ROI_Num = 264
BetaMat=scio.loadmat('./result/BetaMat.mat')['BetaMat']
num_movie,num_sample,num_roi=BetaMat.shape
All=np.zeros((num_movie*num_sample,num_roi))
All_std=np.zeros(num_roi)
for i in range(num_roi):
    temp=BetaMat[:,:,i]
    All[:,i]=temp.reshape(-1)
    All_std[i]=np.std(All[:,i],0,ddof=1)

MeanSIA =np.mean(All,0)
SortedSIA =np.sort(MeanSIA)[::-1]
pos=np.argsort(MeanSIA)[::-1]
SortedStd = All_std[pos]

ROI_Corr=np.zeros(num_roi)
for i in range(num_roi):

    ROI_Corr_M = np.corrcoef(BetaMat[:,:,i])
    #Average correlation coefficient
    triu = np.triu_indices(ROI_Corr_M.shape[0], 1)
    ROI_Corr[i]=np.mean(ROI_Corr_M[triu])

SortedROI_Corr = ROI_Corr[pos]

# Category of each brain region
network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}

roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)
ROI_264=ROI_264[:,np.newaxis]

roi_class=np.squeeze(ROI_264[pos])

roi_class_name=[]
for i in range(ROI_Num):
    roi_class_name.append(network_name[roi_class[i]])

scio.savemat( "./result/SortMIA.mat",
                 {"SortedSIA": SortedSIA,
                  "pos":pos,
                  "SortedStd": SortedStd,
                  "SortedROI_Corr":SortedROI_Corr,
                  "roi_class_name":roi_class_name
                  })
