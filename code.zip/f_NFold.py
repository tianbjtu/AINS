import numpy as np
def NFold(SampleSize, FoldNum):

    MinFeatNumPerFold = int(np.floor(SampleSize / FoldNum))
    Permed = [i for i in range(SampleSize)]
    np.random.shuffle(Permed)
    Permed=np.array(Permed)
    SampleNo={}
    for Tmp in range(FoldNum):
        SampleNo[Tmp] = Permed[Tmp * MinFeatNumPerFold: (Tmp+1) * MinFeatNumPerFold]

    if np.mod(SampleSize, FoldNum):
        for Tmp in range(np.mod(SampleSize, FoldNum)):
            SampleNo[Tmp]=SampleNo[Tmp].tolist()
            SampleNo[Tmp].append(Permed[FoldNum * MinFeatNumPerFold + Tmp])
            SampleNo[Tmp]=np.array(SampleNo[Tmp])
    TestNo={}
    TrainNo={}
    for Tmp in range(FoldNum):
        TestNo[Tmp]=SampleNo[Tmp]
        for i in range(FoldNum):
            if i!=Tmp:
                if Tmp in TrainNo.keys():
                    A = SampleNo[i].tolist()
                    TrainNo[Tmp]=TrainNo[Tmp]+A
                else:
                    A=SampleNo[i].tolist()
                    TrainNo[Tmp]=A
        TrainNo[Tmp]=np.array(TrainNo[Tmp])
    return TrainNo,TestNo,Permed