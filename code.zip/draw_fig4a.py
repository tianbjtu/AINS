# draw fig4a
import numpy as np
import scipy.io as scio
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
Acc=scio.loadmat("./result/Ident_AllRA_264ROI.mat")['Acc']

plt.rcParams['axes.unicode_minus']=False
sns.set(rc={'figure.figsize':(10,6)})
sns.set_theme(style="whitegrid",font='Times New Roman')
sns.set_context("notebook", font_scale=1.3, rc={"lines.linewidth": 2})

x_tick=['Mov1','Mov2','Mov3','Mov4']
y_tick=['Mov1','Mov2','Mov3','Mov4']


Acc[0][0]=1
Acc[1][1]=1
Acc[2][2]=1
Acc[3][3]=1
labels=[]
for value in Acc.flatten():
    if value ==1:
        labels.append("N. A.")
    else:
        labels.append("{:.3f}".format(value))
labels = np.asarray(labels).reshape(4, 4)
my_colormap = LinearSegmentedColormap.from_list("", ["blue","white" ])
ax = sns.heatmap(Acc, annot=labels,fmt='', linewidths=1,cmap=my_colormap,vmin=0.6,vmax=1)
ax.tick_params(labelsize=15)
ax.set_xlabel('Target',fontsize=20, color='k')
ax.set_ylabel('Source',fontsize=20, color='k')
cbar = ax.collections[0].colorbar
cbar.set_label(r'Accuracy', fontsize=20)
ax.set_xticklabels(x_tick,fontsize=15)
ax.set_yticklabels(y_tick,fontsize=15)
scatter_fig = ax.get_figure()
ax.set_title("(a)",loc='left',fontsize=25,y=1.05,x=-0.1,weight='bold')
scatter_fig.savefig("./figure/fig4a",dpi=300)
plt.show()


