import numpy as np
from scipy import stats
def icc(Y, alpha,r0,icc_type="icc(1,1)"):

    [n, k] = Y.shape

    # Degrees of Freedom
    dfc = k - 1
    dfe = (n - 1) * (k - 1)
    dfr = n - 1

    # Sum Square Total
    mean_Y = np.mean(Y)
    SST = ((Y - mean_Y) ** 2).sum()

    # create the design matrix for the different levels
    x = np.kron(np.eye(k), np.ones((n, 1)))  # sessions
    x0 = np.tile(np.eye(n), (k, 1))  # subjects
    X = np.hstack([x, x0])

    # Sum Square Error
    predicted_Y = np.dot(
        np.dot(np.dot(X, np.linalg.pinv(np.dot(X.T, X))), X.T), Y.flatten("F")
    )
    residuals = Y.flatten("F") - predicted_Y
    SSE = (residuals ** 2).sum()

    MSE = SSE / dfe

    # Sum square column effect - between colums
    SSC = ((np.mean(Y, 0) - mean_Y) ** 2).sum() * n
    # MSC = SSC / dfc / n
    MSC = SSC / dfc

    # Sum Square subject effect - between rows/subjects
    SSR = SST - SSC - SSE
    MSR = SSR / dfr

    SSW=SSE+SSC
    MSW = SSW / (n * (k - 1))

    if icc_type == "icc(1,1)":
        ICC=(MSR - MSW) / (MSR + (k - 1) * MSW)
        F = (MSR / MSW) * (1 - r0) / (1 + (k - 1) * r0)
        df1 = n - 1
        df2 = n * (k - 1)
        p = 1 - stats.f.cdf(F, df1, df2)

        FL = F/stats.f.ppf(1-alpha/2, n-1, n*(k-1))
        FU = F * stats.f.ppf(1 - alpha / 2, n * (k - 1), n - 1)

        LB = (FL - 1) / (FL + (k - 1))
        UB = (FU - 1) / (FU + (k - 1))

    return ICC ,LB, UB, F, df1, df2, p
