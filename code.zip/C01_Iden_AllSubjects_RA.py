import numpy as np
import scipy.io as scio

BetaMat=scio.loadmat("./result/BetaMat.mat")["BetaMat"] # 4 * 138 * 264
# A successful identification can be achieved only when the intra-subject PCC was stronger than all 137 inter-subject ones.
num_movie,num_sample,num_roi=BetaMat.shape
Acc = np.zeros((num_movie, num_movie))
ret = np.zeros((num_movie,num_movie,num_sample))
for tmp1 in range(num_movie):
    for tmp2 in range(num_movie):
        AccurateNum = 0
        M1 = BetaMat[tmp1,:,:]
        M2 = BetaMat[tmp2,:,:]
        for tmp3 in range(num_sample):
            tmp=M1[tmp3:tmp3+1,:]
            r = np.corrcoef(np.concatenate((tmp,M2),0))
            MaxR = max(r[0, 1:])
            if (MaxR == r[0, tmp3+1]):
                ret[tmp1, tmp2, tmp3] = MaxR
                AccurateNum = AccurateNum + 1
        Acc[tmp1, tmp2] = AccurateNum / num_sample
scio.savemat("./result/Ident_AllRA_264ROI.mat",{"Acc":Acc})