# Generate AINS  4 films * 138 samples * 264 ROI

import random
import numpy as np
import os
from scipy.optimize import curve_fit
import scipy.io as scio

def func(x, a, b):
    return a + b*x
# 40 samples will be randomly selected as the model, and the AINS will be calculated for other 138 samples

random_num=40
MIA_num=178-random_num
temp= np.array([i for i in range(178)])
random.shuffle(temp)
model_index=temp[0:random_num]
MIA_index=temp[random_num:]

#calculate AINS
BetaMat=np.zeros((4,MIA_num,264)) # 264roi
data_filepath=["./data/Movie1_TS264.mat","./data/Movie2_TS264.mat","./data/Movie3_TS264.mat","./data/Movie4_TS264.mat"]
for m in range(4):
    data=scio.loadmat(data_filepath[m])['TS']
    num_roi,num_time,num_sample=data.shape
    Movie_Matrix = np.zeros((MIA_num, num_roi))
    # mean value of random sample
    temp = data[:,:,model_index]
    Movie_Mean = np.mean(temp, axis=2)
    for i in range(MIA_num):
        for j in range(num_roi):
            # partial least squares regression
            popt, pcov = curve_fit(func, Movie_Mean[j,:], data[j,:, MIA_index[i]])
            # Get the fitting coefficient in popt
            Movie_Matrix[i, j] = popt[1]
    BetaMat[m,:,:] = Movie_Matrix
scio.savemat("result/BetaMat.mat", {'BetaMat':BetaMat,'MIA_index':MIA_index})

