# draw fig2
import numpy as np
import scipy.io as scio
import seaborn as sns
import pandas as pd

from matplotlib import pyplot as plt
BetaMat=scio.loadmat("./result/BetaMat.mat")["BetaMat"]
network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}
roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)
ROI_264=ROI_264[:,np.newaxis]

index=[]
NetNo=[]
for i in network_name.keys():
    NetNo.append(i)
    roi_index=np.where(ROI_264==i)[0]
    index.append(roi_index)
NetNo=np.array(NetNo)


tmp =np.mean(BetaMat,0)

RA = np.mean(tmp,0)


RANet=np.zeros(11)
for i in range(11):
    RANet[i]=np.mean(RA[index[i]])

roi_class=[network_name[i] for i in NetNo]


df = pd.DataFrame({
                "roi_name":roi_class,
                "NetWork-Wise AINS":RANet.tolist(),
                "ROI":["CC_and_HO" for i in range(11)]
})

plt.rcParams['axes.unicode_minus']=False
sns.set_theme(style="whitegrid",font='Times New Roman')
sns.set_context("notebook", font_scale=3, rc={"lines.linewidth": 2})
fig,sub_ax=plt.subplots(nrows=1,ncols=2,figsize = (48,22))

ax1=sns.barplot(x="roi_name", y="NetWork-Wise AINS",data=df,color="#9999CC")
bar_index=np.arange(11)
for a,b in zip(bar_index,RANet):
    ax1.text(a,b,' %.3f'%b,ha='center',va='bottom',fontsize=35,rotation=60)
ax1.set_ylim(0.1, 1.0)
ax1.tick_params(labelsize=40)

ax1.set_ylabel("NetWork-Wise AINS",fontsize=45)
ax1.set_xlabel("")
ax1.set_xticklabels(roi_class,rotation=60)
ax1.set_title("(b)",loc='left',fontsize=60,y=1.05,x=-0.13,weight='bold')

fig.savefig("./figure/fig2", dpi=300)
plt.show()


