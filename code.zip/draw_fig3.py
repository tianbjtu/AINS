# draw fig3
import numpy as np
import scipy.io as scio
import seaborn as sns
from matplotlib import pyplot as plt
import pandas as pd
from matplotlib.ticker import FuncFormatter

network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}

ICC_NetMean=scio.loadmat("./result/ICC_Net_FullTS ICC_NetMean.mat")["ICC_NetMean"]
ICC_NetNo=scio.loadmat("./result/ICC_Net_FullTS ICC_NetMean.mat")["ICC_NetNo"]
Data = np.squeeze(ICC_NetMean)
ICC_NetNo=np.squeeze(ICC_NetNo)
roi_class=[network_name[ICC_NetNo[i]] for i in range(len(ICC_NetNo))]

plt.rcParams['axes.unicode_minus']=False
plt.rcParams['font.sans-serif'] = ['Times New Roman']
sns.set_context("notebook", font_scale=3, rc={"lines.linewidth": 2})
fig=plt.figure(figsize = (46.2,40.4))
fig.subplots_adjust(hspace=0.2,wspace=0.4)

# fig3b
df = pd.DataFrame({
                "ROI_name":roi_class,
                "NetWork-Wise ICC":Data.tolist(),
                "ROI":["CC_and_HO" for i in range(11)]
})

with sns.axes_style("whitegrid"):
    plt.subplot(222)
    ax1 = sns.barplot(x="ROI_name", y="NetWork-Wise ICC", data=df, color="#9999CC")
    bar_index = np.arange(11)
    # 柱子上的数字显示
    for a, b in zip(bar_index, Data):
        ax1.text(a, b, '%.3f' % b, ha='center', va='bottom', fontsize=40, rotation=60)
    ax1.set_ylim(0, 0.8)
    ax1.tick_params(labelsize=45)
    ax1.set_ylabel("NetWork-Wise ICC", fontsize=50)
    ax1.set_xlabel("")
    ax1.set_xticklabels(roi_class, rotation=60)
    ax1.set_title("(b)", loc='left', fontsize=65, y=1.05, x=-0.15, weight='bold')

# fig3c
ICC_all_data=scio.loadmat("./result/ICC_RA_AllSubj.mat")['ICC_RA']
ICC_all_data=np.squeeze(ICC_all_data)
roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)
ROI_264=ROI_264[:,np.newaxis]
index=[]
NetNo=[]
for i in network_name.keys():
    NetNo.append(i)
    roi_index=np.where(ROI_264==i)[0]
    index.append(roi_index)
NetNo=np.array(NetNo)
level=[]
net_name=[]
rate=[]
for i in range(len(NetNo)):
    poor_num=0
    fair_num=0
    good_num=0
    excellent_num=0
    for roi_No in index[i]:
        if ICC_all_data[roi_No]<0.4:
            poor_num+=1
        elif ICC_all_data[roi_No]<0.6:
            fair_num+=1
        elif ICC_all_data[roi_No]<0.75:
            good_num+=1
        else:
            excellent_num+=1
    level.append('excellent')
    rate.append(np.round(excellent_num / len(index[i]), 4))
    net_name.append(network_name[NetNo[i]])
    level.append('good')
    rate.append(np.round(good_num / len(index[i]), 4))
    net_name.append(network_name[NetNo[i]])
    level.append('fair')
    rate.append(np.round(fair_num / len(index[i]), 4))
    net_name.append(network_name[NetNo[i]])
    level.append('poor')
    rate.append(np.round(poor_num/len(index[i]),4))
    net_name.append(network_name[NetNo[i]])
roi_class=[network_name[NetNo[i]] for i in range(len(NetNo))]
stacked = pd.DataFrame({'Group': net_name, 'Value': level, 'Percentage': rate})
with sns.axes_style("whitegrid"):
    plt.subplot(223)
    ax2 = sns.histplot(stacked, x='Group', hue='Value', weights='Percentage', palette="Purples", multiple='stack',
                       shrink=0.75)
    ax2.legend(labels=stacked['Value'].unique()[::-1], bbox_to_anchor=(1, 1), fontsize=40)
    ax2.tick_params(labelsize=45)
    ax2.set_ylabel("Percentage", fontsize=50)
    ax2.set_xlabel("")
    ax2.set_xticklabels(roi_class, rotation=60)

    def to_percent(temp, position):
        return '%1.00f' % (100 * temp) + '%'

    ax2.yaxis.set_major_formatter(FuncFormatter(to_percent))
    ax2.set_title("(c)", loc='left', fontsize=65, y=1.05, x=-0.15, weight='bold')

# fig3D
AINS=scio.loadmat("./result/BetaMat.mat")["BetaMat"]

AINS =np.mean(AINS,0)

AINS = np.mean(AINS,0)
df = pd.DataFrame({'ROI-Wise AINS': AINS, 'ROI-Wise ICC': ICC_all_data})
with sns.axes_style("white"):
    plt.subplot(224)
    ax3 = sns.scatterplot(x='ROI-Wise AINS', y='ROI-Wise ICC', data=df, s=25 ** 2, marker='o', color="#9999CC")
    ax3.tick_params(labelsize=45)
    ax3.set_ylabel("ROI-Wise ICC", fontsize=50)
    ax3.set_xlabel("ROI-Wise AINS", fontsize=50)
    parameter = np.polyfit(AINS, ICC_all_data, 1)
    y = parameter[0] * AINS + parameter[1]
    plt.plot(AINS, y, color='b', linewidth=10)
    ax3.text(0.1, 0.75, 'R = %.3f' % parameter[0], fontsize=45)
    ax3.set_title("(d)", loc='left', fontsize=65, y=1.05, x=-0.15, weight='bold')

fig.savefig("./figure/fig3",dpi=300)
plt.show()
