import numpy as np
import pandas as pd
import scipy.io as scio
import seaborn as sns
from matplotlib import pyplot as plt

MAX_Y = 1750
R=scio.loadmat("./result/Pred_Perm5000_PLSR264ROI_Gender.mat")['R'] # 5000个4 * 4
MeanR=scio.loadmat("./result/Pred_PLSR264ROI_Gender_DIM5.mat")['MeanR']

Rtrue=[ round(MeanR[i][i],3) for i in range(4)]
plt.rcParams['axes.unicode_minus']=False
sns.set_theme(style="whitegrid",font='Times New Roman')
fig,sub_ax=plt.subplots(nrows=2,ncols=2,figsize = (15.3,15.3))
fig.subplots_adjust(hspace=0.3,wspace=0.3)
ax_list=[sub_ax[0][0],sub_ax[0][1],sub_ax[1][0],sub_ax[1][1]]
fig_No=['(b)','(c)','(d)','(e)']
P_vuale=[]
over_true_num=[]
Global_Rmax=0
Global_Rmin=1
for movNo in range(4):
    R_Perm = R[:, movNo, movNo]
    Rmax = max(R_Perm)
    Rmin = min(R_Perm)
    if Global_Rmax<Rmax:
        Global_Rmax=Rmax
    if Global_Rmax< Rtrue[movNo]:
        Global_Rmax=Rtrue[movNo]
    if Global_Rmin>Rmin:
        Global_Rmin=Rmin

Global_Rmax = np.round(Global_Rmax,2)
Global_Rmin = np.round(Global_Rmin,2)

for movNo in range(4):
    R_Perm = R[:, movNo, movNo]
    over_true_num.append(sum(R_Perm > Rtrue[movNo]))
    P_vuale.append((over_true_num[movNo]+1)/ 5001)

    A = [ i/100 for i in range(int(Global_Rmin*100),int(Global_Rmax*100+3),3)]

    ACC=np.zeros(len(A))
    for i in range(len(A)):
        tmp1=R_Perm >= A[i] - 0.015
        tmp2=R_Perm<A[i]+0.015
        ACC[i]=int(sum(tmp1*tmp2))


    df = pd.DataFrame({
        "temp_label": A,
        "ACC": ACC,
    })

    ax=sns.barplot(x="temp_label", y="ACC",data=df, color="#9999CC",ax=ax_list[movNo])
    width = ax.patches[0].get_width()
    ax.bar(int((Rtrue[movNo]-Global_Rmin+0.015)/0.03)+width/2,MAX_Y,0.1,align='center',color='r',)

    ax.set_ylim(0, MAX_Y)
    ax.tick_params(labelsize=20)
    vals = ax.get_xticks()
    ax.set_xticklabels(['{:.1%}'.format(Global_Rmin+0.03*x) for x in vals], size=20,rotation=45)
    ax.set_ylabel("Number of Classification Accuracies",fontsize=25)
    ax.set_xlabel("Mov"+str(movNo+1), fontsize=25,weight='bold')
    ax.set_title(fig_No[movNo], loc='left', fontsize=35, y=1.05, x=-0.15, weight='bold')

fig.savefig("./figure/fig5bcde",dpi=300)
plt.show()

