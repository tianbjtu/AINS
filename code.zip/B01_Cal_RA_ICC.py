import numpy as np
import scipy.io as scio
import scipy
from f_ICC import icc


network_name={1:"SMN", 3:"CON", 4:"ALN", 5:"DMN", 7:"VisN", 8:"FPN", 9:"SAN",
10:"SubcN", 11:"VAN", 12:"DAN", -1:"UncN"}

BetaMat=scio.loadmat("./result/BetaMat.mat")["BetaMat"]
# Category of each brain region
roi_network=[]
with open("./data/264_network.txt") as file:
    for item in file:
        roi_network.append(int(item))

ROI_264=np.array(roi_network)
ROI_264=ROI_264[:,np.newaxis]

num_movie,num_sample,num_roi=BetaMat.shape

ICC_RA=np.zeros(num_roi)
LB_RA=np.zeros(num_roi)
UB_RA=np.zeros(num_roi)
F_RA=np.zeros(num_roi)
p_RA=np.zeros(num_roi)



for Tmp in range(num_roi):
    ICC_RA[Tmp],LB_RA[Tmp], UB_RA[Tmp], F_RA[Tmp], df1, df2, p_RA[Tmp]= icc(BetaMat[:,:,Tmp].T,0.05,0)

scio.savemat('./result/ICC_RA_AllSubj.mat',{'ICC_RA':ICC_RA,'LB_RA':LB_RA,'UB_RA':UB_RA})

ICC_NetMean=[]
ICC_NetNo=[]
# Average ICC per network
for NetNo in network_name.keys():
    ICC_NetNo.append(NetNo)
    ICC_NetMean.append(np.mean(ICC_RA[np.where(ROI_264 == NetNo)[0]]))

ICC_NetMean=np.array(ICC_NetMean)
ICC_NetNo=np.array(ICC_NetNo)
scio.savemat("./result/ICC_Net_FullTS ICC_NetMean.mat",{"ICC_NetMean":ICC_NetMean,"ICC_NetNo":ICC_NetNo})

ICC_Glob = np.mean(ICC_RA)
LB_Glob = np.mean(LB_RA)
UB_Glob = np.mean(UB_RA)
scio.savemat("./result/ICC_Glob_FullTS.mat",{"ICC_Glob":ICC_Glob,"LB_Glob": LB_Glob,"UB_Glob":UB_Glob})
