import numpy as np
import scipy.io as scio
import csv
import pandas as pd

data=scio.loadmat('./result/SortMIA.mat')
corrdinate_data = pd.read_csv('./data/Power264coordinate.csv')
rows=[]
sorted_Mean_IRNS=data['SortedSIA'][0]
sorted_Std_IRNS=data['SortedStd'][0]
sorted_pos=data['pos'][0]
roi_net_name=data['roi_class_name']
order_corrd=[]
X=corrdinate_data['MNI_X'].to_numpy()
Y=corrdinate_data['MNI_Y'].to_numpy()
Z=corrdinate_data['MNI_Z'].to_numpy()
for i in range(264):
    str_corrd="( "+str(+X[i])+", "+str(Y[i])+", "+str(Z[i])+" )"
    order_corrd.append(str_corrd)
for i in range(len(sorted_pos)):
    one_row={
             'MNI Coordinate':order_corrd[sorted_pos[i]],
             'Network Affiliation':roi_net_name[i],
             'IRNS*':str(np.round(sorted_Mean_IRNS[i],3))+'+'+str(np.round(sorted_Std_IRNS[i],2))}
    rows.append(one_row)

with open('./result/MeanRoiIRNS.csv', 'w', newline='')as csv_file:
    fieldnames=['MNI Coordinate','Network Affiliation','IRNS*']
    writer = csv.DictWriter(csv_file,fieldnames=fieldnames)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
